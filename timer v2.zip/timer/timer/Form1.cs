﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timer
{
    public partial class Form1 : Form
    {
        public string timen;
        public int f = 0;
        public string s;
        public string mon = " меясц ";
        
        public Form1()
        {
            InitializeComponent();
            DateTime data1 = new DateTime(2022, 12, 14, 15, 51, 00);
            int y = data1.Year - DateTime.Now.Year;
            int d = data1.Day - DateTime.Now.Day;
            int m = data1.Month - DateTime.Now.Month;
            int h = data1.Hour - DateTime.Now.Hour;
            if (data1.Hour < DateTime.Now.Hour)
            {
                h = h * -1;
            }

            int mi = data1.Minute - DateTime.Now.Minute;
            if (data1.Minute < DateTime.Now.Minute)
            {
                mi = 60 + mi;
            }
            int sec = data1.Second - DateTime.Now.Second;
            if (m > 1 && m < 5)
            {
                mon = " месяца ";
            }
            if (m >= 5)
            {
                mon = " месяцев ";
            }
            if (m == 1)
            {
                mon = " месяц ";
            }
            label3.Text = y+ " лет " + m+mon+d+ " дней "  +h+ " часов " + mi + " минут до начала марафона! " + sec+ " секунд ";
            
        }

       
        
    }
}
